import React, {Component} from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Root</h1>
    </div>
  );
}

export default App;
