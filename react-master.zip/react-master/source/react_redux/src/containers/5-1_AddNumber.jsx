import AddNumber from "../components/AddNumber";
import React, { Component } from "react";
export default class extends Component {
  render() {
    return <AddNumber></AddNumber>
  }
} 