import React, { Component } from 'react';

class CreateContent extends Component {
    render() {
      console.log('Content render');
      return (
        <article>
            <h2>Create</h2>
            <form>

            </form>
        </article>
      );
    }
  }

export default CreateContent; 